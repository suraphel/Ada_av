How to get started
==================

Specify the path to microbit_zfp.gpr in your .gpr file or  just copy src files into your Microbit project.

Nav library is for navigating the car and sensor is for getting sensor signal back. Specify pins you will be using of your Microbot in the respective package.

